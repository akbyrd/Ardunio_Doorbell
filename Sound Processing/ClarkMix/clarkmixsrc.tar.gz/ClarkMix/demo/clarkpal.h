// 15-bit BGR palette made from file 
// Pics/clarky.pnm.pal 

#ifndef __clarkpal__
#define __clarkpal__

#include <gba.h>

extern const u32 clarkpal_nbcol;
extern const u16 clarkpal_data[];

#endif
