// 15-bit BGR palette made from file 
// Pics/ascii.pnm.pal 

#ifndef __asciipal__
#define __asciipal__

#include <gba.h>

extern const u32 asciipal_nbcol;
extern const u16 asciipal_data[];

#endif
