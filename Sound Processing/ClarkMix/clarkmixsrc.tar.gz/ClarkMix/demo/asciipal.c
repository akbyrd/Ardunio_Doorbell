// 15-bit BGR palette made from file 
// Pics/ascii.pnm.pal 

#include "asciipal.h"

const u32 asciipal_nbcol=5;
const u16 asciipal_data[]={/* 0 0 0 */ 0x0, /* 64 64 64 */ 0x5EF7, /* 128 128 128 */ 0x5EF7, /* 191 191 191 */ 0x5EF7, /* 255 255 255 */ 0x7FFF} ;
